import { Routes,Route, Navigate } from "react-router-dom";
import InstanceList from "../component/table/instanceList";
import HomePage from "../pages/create_AWS/homePage";
import SignUp from '../component/Signup/Signup';
import FormPage from '../pages/formPage/formPage';
import List from "../pages/list/list";


const AppRoute=(
    <Routes>
        <Route path="/">
            <Route path="/" element={<Navigate to="home"/>}/>
        </Route>
        <Route path='/' element={<HomePage/>}>
            <Route path="/home" element={<SignUp/>}/>
            <Route path='/form' element={<FormPage/>}/>
            <Route path="/list" element={<List/>}/>
            </Route>
    </Routes>
)
export default AppRoute;